#include<iostream>
using namespace std;


void permute(string a,int i){


}


int main(){

	string s;
	cin>>s;
	permute(s);
	return 0;
}