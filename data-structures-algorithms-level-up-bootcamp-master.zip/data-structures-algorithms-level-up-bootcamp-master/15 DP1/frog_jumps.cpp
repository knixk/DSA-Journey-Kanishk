CODING INTERVIEW ~ 20 mins

FROG JUMPS
============
Given an array containing integers, and there is a frog 
sitting at the starting of the array. Each integer represents the 
maximum number of steps frog can take in the array.
Write a function which can calculates the minimum jumps 
required by frog to reach the end of the array.


